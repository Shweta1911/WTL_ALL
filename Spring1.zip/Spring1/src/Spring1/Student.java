package Spring1;
public class Student {
String Name;
int id;

public String getName() {
	return Name;
}

public void setName(String name) {
	Name = name;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

void display() {
	 System.out.println("Hello: "+Name+" "+id);  
}
}
