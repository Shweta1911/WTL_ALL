package Spring_Constructor;
public class Student {
	int id;
	String name;
	public Student(int id) {this.id = id;}  
	  
	public Student(String name) {  this.name = name;} 
		
	public Student(int id, String name) {
		this.id = id;
		this.name = name;
	}
	void show() {
		System.out.println("Name = "+name+"\nId = "+id);
	}

}
